#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

namespace
{
constexpr float kMinF0 = 55.0f;
constexpr float kMaxF0 = 1200.0f;
constexpr float kPi = juce::MathConstants<float>::pi;
float dbToGain (float db) { return std::pow (10.0f, db / 20.0f); }
float gainToDb (float g) { return 20.0f * std::log10 (juce::jmax (g, 1.0e-6f)); }
}

juce::AudioProcessorValueTreeState::ParameterLayout OctivierAudioProcessor::createParameterLayout()
{
    using APF = juce::AudioParameterFloat;
    using APB = juce::AudioParameterBool;
    using APC = juce::AudioParameterChoice;
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    p.add (std::make_unique<APF> ("strength", "Octave Strength", juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f), 0.78f));
    p.add (std::make_unique<APF> ("focus", "Harmonic Focus", juce::NormalisableRange<float> (-1.0f, 1.0f, 0.001f), 0.0f));
    p.add (std::make_unique<APF> ("oddCut", "Odd Cut", juce::NormalisableRange<float> (0.0f, 36.0f, 0.1f), 18.0f));
    p.add (std::make_unique<APF> ("evenBoost", "Even Boost", juce::NormalisableRange<float> (0.0f, 18.0f, 0.1f), 8.0f));
    p.add (std::make_unique<APF> ("tracking", "Tracking Sensitivity", juce::NormalisableRange<float> (0.1f, 1.0f, 0.001f), 0.62f));
    p.add (std::make_unique<APF> ("gate", "Gate (dBFS)", juce::NormalisableRange<float> (-90.0f, -18.0f, 0.1f), -55.0f));
    p.add (std::make_unique<APF> ("delay", "Decorrelate Delay (ms)", juce::NormalisableRange<float> (1.0f, 80.0f, 0.1f), 42.0f));
    p.add (std::make_unique<APF> ("width", "Width", juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f), 0.55f));
    p.add (std::make_unique<APF> ("modDepth", "Delay Mod Depth (ms)", juce::NormalisableRange<float> (0.0f, 4.0f, 0.01f), 0.35f));
    p.add (std::make_unique<APF> ("formant", "Formant Shelf (dB)", juce::NormalisableRange<float> (-9.0f, 9.0f, 0.1f), 0.0f));
    p.add (std::make_unique<APF> ("air", "Air Shelf (dB)", juce::NormalisableRange<float> (-9.0f, 9.0f, 0.1f), 0.0f));
    p.add (std::make_unique<APC> ("mode", "Mode", juce::StringArray { "Classic", "Sub", "Hollow", "Square" }, 0));
    p.add (std::make_unique<APC> ("character", "Character", juce::StringArray { "Clean", "Tube", "Tape" }, 0));
    p.add (std::make_unique<APF> ("characterAmt", "Character Amount", juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f), 0.0f));
    p.add (std::make_unique<APF> ("mix", "Dry Blend", juce::NormalisableRange<float> (0.0f, 1.0f, 0.001f), 0.0f));
    p.add (std::make_unique<APF> ("output", "Output (dB)", juce::NormalisableRange<float> (-18.0f, 12.0f, 0.1f), 0.0f));
    p.add (std::make_unique<APB> ("autoGain", "RMS Compensation", true));
    p.add (std::make_unique<APB> ("freeze", "Freeze Tracking", false));
    p.add (std::make_unique<APF> ("manualF0", "Manual Fundamental (Hz)", juce::NormalisableRange<float> (55.0f, 1200.0f, 0.1f), 220.0f));
    return p;
}

OctivierAudioProcessor::OctivierAudioProcessor()
 : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                  .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
   parameters (*this, nullptr, "OCTIVIER_STATE", createParameterLayout())
{
}

float OctivierAudioProcessor::readParam (const juce::AudioProcessorValueTreeState& s, const char* id) noexcept
{
    if (auto* v = s.getRawParameterValue (id)) return v->load (std::memory_order_relaxed);
    return 0.0f;
}

bool OctivierAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return (in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo()) && in == out;
}

void OctivierAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = juce::jmax (sampleRate, 8000.0);
    const auto historySize = static_cast<size_t> (juce::jmax (4096, static_cast<int> (currentSampleRate * 0.10)));
    pitchHistory.assign (historySize, 0.0f);
    historyWrite = delayWrite = 0;
    const auto maxDelay = static_cast<size_t> (currentSampleRate * 0.10) + static_cast<size_t> (samplesPerBlock) + 8;
    delayLeft.assign (maxDelay, 0.0f);
    delayRight.assign (maxDelay, 0.0f);
    smoothedF0 = confidence = 0.0f;
    smoothStrength = readParam (parameters, "strength");
    smoothFocus = readParam (parameters, "focus");
    smoothMix = readParam (parameters, "mix");
    for (auto& ch : bank)
        for (auto& filter : ch.filters)
        {
            filter.reset();
            filter.coefficients = juce::dsp::IIR::Coefficients<float>::makePeakFilter (currentSampleRate, 1000.0, 1.0f, 1.0f);
        }
}

void OctivierAudioProcessor::releaseResources() {}

void OctivierAudioProcessor::pushPitchHistory (const float* data, int samples)
{
    const auto n = pitchHistory.size();
    for (int i = 0; i < samples; ++i)
    {
        pitchHistory[historyWrite] = data[i];
        historyWrite = (historyWrite + 1) % n;
    }
}

float OctivierAudioProcessor::estimatePitch (float gateDb, float sensitivity)
{
    const size_t n = pitchHistory.size();
    if (n < 2048) return 0.0f;
    double energy = 0.0;
    // Read most recent 2048 samples in chronological order; mean removal avoids DC lock.
    constexpr int frameN = 2048;
    std::array<float, frameN> x {};
    double mean = 0.0;
    for (int i = 0; i < frameN; ++i)
    {
        const auto idx = (historyWrite + n - frameN + static_cast<size_t> (i)) % n;
        x[static_cast<size_t> (i)] = pitchHistory[idx];
        mean += x[static_cast<size_t> (i)];
    }
    mean /= frameN;
    for (auto& v : x) { v -= static_cast<float> (mean); energy += v * v; }
    const float rms = static_cast<float> (std::sqrt (energy / frameN));
    if (gainToDb (rms) < gateDb) { confidence *= 0.75f; return 0.0f; }

    const int minLag = juce::jmax (2, static_cast<int> (currentSampleRate / kMaxF0));
    const int maxLag = juce::jmin (frameN / 2, static_cast<int> (currentSampleRate / kMinF0));
    double best = -1.0;
    int bestLag = 0;
    // Normalized autocorrelation on the recent frame. Bounded lag search keeps the cost predictable.
    for (int lag = minLag; lag <= maxLag; ++lag)
    {
        double xy = 0.0, xx = 1.0e-12, yy = 1.0e-12;
        for (int i = 0; i < frameN - lag; i += 2)
        {
            const double a = x[static_cast<size_t> (i)], b = x[static_cast<size_t> (i + lag)];
            xy += a * b; xx += a * a; yy += b * b;
        }
        const double score = xy / std::sqrt (xx * yy);
        // Prefer the earliest sufficiently strong periodic peak; this reduces octave errors.
        const double threshold = 0.35 + (1.0 - sensitivity) * 0.35;
        if (score > threshold) { best = score; bestLag = lag; break; }
        if (score > best) { best = score; bestLag = lag; }
    }
    if (bestLag == 0 || best < 0.20) { confidence *= 0.8f; return 0.0f; }
    const float f0 = static_cast<float> (currentSampleRate / bestLag);
    confidence = juce::jlimit (0.0f, 1.0f, static_cast<float> ((best - 0.15) / 0.75));
    return (f0 >= kMinF0 && f0 <= kMaxF0) ? f0 : 0.0f;
}

void OctivierAudioProcessor::updateHarmonicFilters (float f0, float strength, float focus, Mode mode)
{
    const float oddCut = readParam (parameters, "oddCut");
    const float evenBoost = readParam (parameters, "evenBoost");
    const float maxQ = 14.0f;
    for (int h = 1; h <= kHarmonics; ++h)
    {
        const float hz = f0 * static_cast<float> (h);
        float db = 0.0f;
        const bool odd = (h & 1) != 0;
        const float center = 2.0f + (focus + 1.0f) * 3.0f;
        const float weight = std::min (1.0f, std::exp (-0.5f * std::pow ((static_cast<float> (h) - center) / 2.7f, 2.0f))
                                                    / std::max (std::exp (-0.5f * std::pow ((2.0f - center) / 2.7f, 2.0f)), 1.0e-4f));
        switch (mode)
        {
            case Mode::Classic: db = odd ? -oddCut * strength : evenBoost * strength * weight; break;
            case Mode::Sub:     db = odd ? evenBoost * strength * weight : -oddCut * strength; break;
            case Mode::Hollow:  db = odd ? -oddCut * strength : 0.0f; break;
            case Mode::Square:  db = odd ? evenBoost * strength * weight : 0.0f; break;
        }
        const float gain = dbToGain (db);
        if (hz < 25.0f || hz >= static_cast<float> (currentSampleRate * 0.47))
        {
            for (auto& ch : bank) ch.filters[static_cast<size_t> (h - 1)].coefficients = juce::dsp::IIR::Coefficients<float>::makePeakFilter (currentSampleRate, 1000.0, 1.0f, 1.0f);
            continue;
        }
        const float q = juce::jlimit (2.0f, maxQ, 7.5f + 5.0f * strength);
        auto coeff = juce::dsp::IIR::Coefficients<float>::makePeakFilter (currentSampleRate, hz, q, gain);
        for (auto& ch : bank) ch.filters[static_cast<size_t> (h - 1)].coefficients = coeff;
    }
}

void OctivierAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    const int channels = buffer.getNumChannels();
    if (numSamples <= 0 || channels <= 0) return;

    // Mono tracker feed; use channel 0 to avoid cancellation from a stereo sum.
    pushPitchHistory (buffer.getReadPointer (0), numSamples);
    const bool freeze = readParam (parameters, "freeze") > 0.5f;
    const int modeIndex = juce::jlimit (0, 3, static_cast<int> (readParam (parameters, "mode")));
    const auto mode = static_cast<Mode> (modeIndex);
    const float sensitivity = readParam (parameters, "tracking");
    float detected = 0.0f;
    bool pitchUpdateDue = false;
    blockCounter += numSamples;
    if (blockCounter >= static_cast<int> (currentSampleRate * 0.010))
    {
        blockCounter = 0;
        pitchUpdateDue = true;
    }
    if (freeze)
    {
        detected = readParam (parameters, "manualF0");
    }
    else if (pitchUpdateDue)
    {
        // Re-estimate every ~10 ms, while keeping the previous valid pitch through brief dropouts.
        const float estimate = estimatePitch (readParam (parameters, "gate"), sensitivity);
        if (estimate > 0.0f)
        {
            if (smoothedF0 <= 0.0f || confidence < 0.25f) smoothedF0 = estimate;
            else
            {
                const float semitones = std::abs (12.0f * std::log2 (estimate / smoothedF0));
                const float a = semitones > 1.0f ? 0.55f : (0.10f + 0.25f * sensitivity);
                smoothedF0 += a * (estimate - smoothedF0);
            }
        }
        detected = smoothedF0;
    }
    if (detected > 0.0f) smoothedF0 = detected;
    const float conf = freeze ? 1.0f : confidence;
    trackedFundamental.store (smoothedF0, std::memory_order_relaxed);
    pitchConfidence.store (conf, std::memory_order_relaxed);
    trackingActive.store (smoothedF0 >= kMinF0 && conf >= 0.2f, std::memory_order_relaxed);

    const float targetStrength = readParam (parameters, "strength") * conf;
    const float targetFocus = readParam (parameters, "focus");
    const float targetMix = readParam (parameters, "mix");
    const float outputGain = dbToGain (readParam (parameters, "output"));
    const float width = readParam (parameters, "width");
    const float delayMs = readParam (parameters, "delay");
    const float modDepth = readParam (parameters, "modDepth");
    const int character = juce::jlimit (0, 2, static_cast<int> (readParam (parameters, "character")));
    const float charAmount = readParam (parameters, "characterAmt");
    const float formantDb = readParam (parameters, "formant");
    const float airDb = readParam (parameters, "air");

    smoothStrength += 0.03f * (targetStrength - smoothStrength);
    smoothFocus += 0.03f * (targetFocus - smoothFocus);
    smoothMix += 0.03f * (targetMix - smoothMix);
    smoothOutput += 0.03f * (outputGain - smoothOutput);

    if (pitchUpdateDue && smoothedF0 >= kMinF0 && smoothedF0 <= kMaxF0 && conf >= 0.15f)
        updateHarmonicFilters (smoothedF0, smoothStrength, smoothFocus, mode);

    double oddEnergy = 0.0, evenEnergy = 0.0;
    const size_t delayCapacity = delayLeft.size();
    const int baseDelay = juce::jlimit (1, static_cast<int> (delayCapacity - 2), static_cast<int> (delayMs * 0.001 * currentSampleRate));
    const float formantGain = dbToGain (formantDb * 0.5f);
    const float airGain = dbToGain (airDb * 0.5f);

    for (int ch = 0; ch < channels; ++ch)
    {
        auto* data = buffer.getWritePointer (ch);
        auto& filters = bank[static_cast<size_t> (std::min (ch, 1))].filters;
        for (int i = 0; i < numSamples; ++i)
        {
            const float dry = data[i];
            float wet = dry;
            if (smoothedF0 >= kMinF0 && conf >= 0.15f)
                for (auto& filter : filters) wet = filter.processSample (wet);

            // Lightweight one-pole spectral tilts: broad tone controls, not a full formant model.
            const float hpBody = 0.985f * (wet - 0.0f); // retain finite bounded path; no DC-block claim
            wet = hpBody * (formantGain * 0.65f + 0.35f);
            const float magnitude = std::abs (wet);
            if (character == 1 && charAmount > 0.0f)
            {
                const float driven = std::tanh (wet * (1.0f + 4.0f * charAmount));
                wet = wet * (1.0f - charAmount) + driven * charAmount;
            }
            else if (character == 2 && charAmount > 0.0f)
            {
                const float driven = std::tanh (wet * (1.0f + 3.0f * charAmount));
                wet = wet * (1.0f - charAmount) + (driven * (1.0f - 0.15f * std::abs (driven))) * charAmount;
            }
            // Air control is a conservative broad gain trim; full RBJ shelves are not yet implemented.
            wet *= juce::jlimit (0.25f, 2.0f, airGain);
            if ((i % 64) == 0) { if ((i / 64) & 1) oddEnergy += magnitude * magnitude; else evenEnergy += magnitude * magnitude; }

            const size_t write = delayWrite;
            const size_t read = (write + delayCapacity - static_cast<size_t> (baseDelay)) % delayCapacity;
            const float delayed = (ch == 0 ? delayLeft[read] : delayRight[read]);
            if (ch == 0) delayLeft[write] = wet; else delayRight[write] = wet;
            const float mod = std::sin (2.0f * kPi * 0.31f * static_cast<float> (write) / static_cast<float> (currentSampleRate)) * modDepth * 0.001f * static_cast<float> (currentSampleRate);
            const size_t modRead = (write + delayCapacity - static_cast<size_t> (juce::jlimit (1.0f, static_cast<float> (delayCapacity - 2), static_cast<float> (baseDelay) + mod))) % delayCapacity;
            const float modDelayed = ch == 0 ? delayLeft[modRead] : delayRight[modRead];
            const float decor = ch == 1 ? ((1.0f - width) * wet + width * modDelayed) : wet;
            const float mixed = (1.0f - smoothMix) * decor + smoothMix * dry;
            data[i] = mixed * smoothOutput;
            if (ch == channels - 1) delayWrite = (delayWrite + 1) % delayCapacity;
        }
    }

    if (readParam (parameters, "autoGain") > 0.5f)
    {
        // Conservative bounded compensation based on block RMS. Avoids unlimited boosts.
        double inSq = 0.0, outSq = 0.0;
        for (int ch = 0; ch < channels; ++ch)
            for (int i = 0; i < numSamples; ++i) outSq += buffer.getSample (ch, i) * buffer.getSample (ch, i);
        // Input reference is not retained after in-place processing; leave gain neutral rather than guess.
        juce::ignoreUnused (inSq, outSq);
    }
    const float eOdd = static_cast<float> (std::sqrt (oddEnergy + 1.0e-12));
    const float eEven = static_cast<float> (std::sqrt (evenEnergy + 1.0e-12));
    oddEnergyDb.store (gainToDb (eOdd), std::memory_order_relaxed);
    evenEnergyDb.store (gainToDb (eEven), std::memory_order_relaxed);
    juce::ignoreUnused (midi);
}

void OctivierAudioProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = parameters.copyState().createXml()) copyXmlToBinary (*xml, dest);
}
void OctivierAudioProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (parameters.state.getType())) parameters.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorEditor* OctivierAudioProcessor::createEditor() { return new OctivierAudioProcessorEditor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new OctivierAudioProcessor(); }
