#pragma once
#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <vector>

/** Octivier real-time processor.
    This is a harmonic-timbre sculptor, not a pitch shifter: no octave-up pitch
    translation is guaranteed. Delay/history buffers are allocated in prepareToPlay. JUCE filter coefficient
    factories may allocate during coefficient refresh, so this version is not yet
    certified allocation-free or safe for strict real-time use.
*/
class OctivierAudioProcessor final : public juce::AudioProcessor
{
public:
    static constexpr int kHarmonics = 16;
    enum class Mode { Classic = 0, Sub = 1, Hollow = 2, Square = 3 };
    enum class Character { Clean = 0, Tube = 1, Tape = 2 };

    OctivierAudioProcessor();
    ~OctivierAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.25; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    juce::AudioProcessorValueTreeState parameters;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    // Read-only UI telemetry; atomics avoid UI/audio-thread data races.
    float getTrackedFundamental() const noexcept { return trackedFundamental.load(); }
    float getPitchConfidence() const noexcept { return pitchConfidence.load(); }
    float getOddEnergyDb() const noexcept { return oddEnergyDb.load(); }
    float getEvenEnergyDb() const noexcept { return evenEnergyDb.load(); }
    bool isTracking() const noexcept { return trackingActive.load(); }

private:
    struct BiquadBank
    {
        std::array<juce::dsp::IIR::Filter<float>, kHarmonics> filters;
    };
    double currentSampleRate = 48000.0;
    int blockCounter = 0;
    std::vector<float> pitchHistory;
    size_t historyWrite = 0;
    std::array<BiquadBank, 2> bank;
    std::vector<float> delayLeft, delayRight;
    size_t delayWrite = 0;
    float smoothedF0 = 0.0f;
    float confidence = 0.0f;
    float smoothStrength = 0.85f;
    float smoothFocus = 0.0f;
    float smoothMix = 0.0f;
    float smoothOutput = 1.0f;
    float previousMidiHz = 0.0f;
    std::atomic<float> trackedFundamental { 0.0f }, pitchConfidence { 0.0f };
    std::atomic<float> oddEnergyDb { -120.0f }, evenEnergyDb { -120.0f };
    std::atomic<bool> trackingActive { false };

    float estimatePitch (float gateDb, float sensitivity);
    void updateHarmonicFilters (float f0, float strength, float focus, Mode mode);
    void pushPitchHistory (const float* data, int samples);
    static float readParam (const juce::AudioProcessorValueTreeState&, const char* id) noexcept;
    static juce::String paramID (const char* name) { return name; }
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OctivierAudioProcessor)
};
