cmake_minimum_required(VERSION 3.22)
project(Octivier VERSION 1.0.0 LANGUAGES CXX)

# Supply JUCE through -DJUCE_DIR=/path/to/JUCE or place it in ./JUCE.
if (NOT DEFINED JUCE_DIR)
    set(JUCE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/JUCE" CACHE PATH "Path to JUCE source tree")
endif()
if (NOT EXISTS "${JUCE_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "JUCE not found. Set -DJUCE_DIR=/path/to/JUCE (JUCE 8 recommended). See README.md.")
endif()
add_subdirectory("${JUCE_DIR}" JUCE)

juce_add_plugin(Octivier
    COMPANY_NAME "Octivier Audio"
    BUNDLE_ID "audio.octivier.harmonicsculptor"
    PLUGIN_MANUFACTURER_CODE Octv
    PLUGIN_CODE Ocv1
    FORMATS VST3 AU Standalone
    PRODUCT_NAME "Octivier Harmonic Sculptor"
    DESCRIPTION "Pitch-aware harmonic emphasis and decorrelation"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT TRUE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE
)

target_sources(Octivier PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginEditor.cpp
)
target_compile_features(Octivier PRIVATE cxx_std_17)
target_compile_definitions(Octivier PUBLIC
    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
)
target_link_libraries(Octivier PRIVATE
    juce::juce_audio_utils
    juce::juce_dsp
    PUBLIC juce::juce_recommended_config_flags
           juce::juce_recommended_lto_flags
           juce::juce_recommended_warning_flags
)

option(OCTIVIER_BUILD_TESTS "Build JUCE-backed smoke tests" OFF)
if (OCTIVIER_BUILD_TESTS)
    enable_testing()
    juce_add_console_app(OctivierSmokeTests PRODUCT_NAME "Octivier Smoke Tests")
    target_sources(OctivierSmokeTests PRIVATE Tests/SmokeTests.cpp Source/PluginProcessor.cpp)
    target_compile_features(OctivierSmokeTests PRIVATE cxx_std_17)
    target_compile_definitions(OctivierSmokeTests PRIVATE JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JucePlugin_Name="Octivier")
    target_link_libraries(OctivierSmokeTests PRIVATE juce::juce_audio_utils juce::juce_dsp juce::juce_recommended_config_flags)
    add_test(NAME OctivierSmokeTests COMMAND OctivierSmokeTests)
endif()
