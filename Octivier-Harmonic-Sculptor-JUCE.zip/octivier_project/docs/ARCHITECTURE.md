# Architecture Notes

- `PluginProcessor` owns APVTS parameters, pitch history, harmonic filters, delay memory, and telemetry atomics.
- Pitch estimation uses the first input channel, a recent 2048-sample window, mean removal, and normalized autocorrelation over a bounded lag range.
- The filter bank is refreshed on the audio thread at a bounded cadence. JUCE coefficient factories may allocate, so this build is not allocation-free and must not be described as strict-realtime-certified. Move coefficient generation off the audio thread and swap prebuilt coefficient sets safely before release.
- The wet path is filtered and optionally saturated, then delayed/decorrelated on the right channel. Dry blend is a linear parallel mix.
- `PluginEditor` uses APVTS attachments. UI telemetry reads atomics; parameter writes are routed through JUCE host notifications.

## Known implementation risks

The first-order prototype intentionally keeps its DSP scope narrow. Review `processBlock` before production use: verify delay indexing for every channel/block size, improve the pitch estimator, avoid all filter coefficient construction on the audio thread (precompute or safely swap immutable coefficient sets), and implement true shelves/auto-gain. Use sanitizers and host stress tests before treating it as realtime-certified.
