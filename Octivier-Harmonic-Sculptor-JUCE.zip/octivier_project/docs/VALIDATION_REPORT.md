# Octivier Validation Report

**Report date:** 2026-10-12  
**Build status:** NOT RUN in this environment  
**Classification:** Engineering prototype; not release-certified

## Implementation status

| Area | Status | Evidence / limitation |
|---|---|---|
| JUCE processor/editor source | IMPLEMENTED | Source files and CMake target are present. |
| Host parameter exposure | IMPLEMENTED | APVTS parameters and slider/combo/toggle attachments. |
| State save/restore | IMPLEMENTED | JUCE ValueTree XML binary serialization; smoke test included. |
| VST3/AU/Standalone project definitions | IMPLEMENTED | JUCE CMake formats; AU is macOS-only. Build not run. |
| Pitch tracker | IMPLEMENTED, UNVERIFIED | Bounded normalized autocorrelation; octave errors/dropouts remain possible. |
| Harmonic filter bank | IMPLEMENTED, UNVERIFIED | 16 peak-filter slots; no measured golden curves. |
| Factory presets | IMPLEMENTED | UI presets are parameter snapshots; not yet a separate preset file format. |
| Stereo decorrelation | IMPLEMENTED, UNVERIFIED | Delay-based; phase/comb behavior needs measurement. |
| Formant / Air shelves | NOT IMPLEMENTED AS NAMED | Current controls are gain trims, not proper shelf filters. |
| Automatic RMS compensation | NOT IMPLEMENTED | Parameter exists; current processing intentionally leaves gain neutral. |
| Oversampled saturation | NOT IMPLEMENTED | Tube/Tape waveshaping runs at host rate; aliasing possible. |
| Realtime allocation/lock audit | NOT VERIFIED | Requires code audit and host stress testing. |
| CPU and latency measurement | NOT VERIFIED | No benchmark run; decorrelation introduces delay. |
| Pluginval / DAW host runs | NOT RUN | Requires compiled binaries and host environment. |
| Audio perceptual/ABX tests | NOT RUN | No listening data supplied. |

## Test plan before release

1. Build Release and Debug on each target OS with the stated JUCE version.
2. Run `OctivierSmokeTests` and add deterministic tests for pitch error over 55–1200 Hz, noise/silence gate behavior, state round-trip, parameter bounds, and finite output at 44.1/48/88.2/96/192 kHz.
3. Run pluginval at strictness appropriate to the target and test load/unload, automation, state recall, mono/stereo, sample-rate changes, offline rendering, and suspend/resume in at least two DAWs.
4. Measure actual reported latency and tail. Confirm delay buffer safety and stereo channel behavior under arbitrary block sizes.
5. Measure each filter's response against golden frequency-response curves; test filter stability near Nyquist and under rapid pitch glides.
6. Add oversampling or disable saturation modes pending aliasing measurements.
7. Implement true RBJ shelves for Formant/Air and real RMS compensation, or remove/rename those controls before public beta.
8. Conduct loudness-matched listening and ABX comparisons against a clean duplicate and conventional pitch-shifted octave double. Report results without claiming a guaranteed octave-up effect.

## Release gate

**BLOCKED** until a real JUCE build, automated tests, pluginval/DAW host tests, DSP response measurements, real-time audit, and listening evaluation are completed. No release certification is claimed by this report.
